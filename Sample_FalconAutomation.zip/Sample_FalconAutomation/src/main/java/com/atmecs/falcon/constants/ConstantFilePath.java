package com.atmecs.falcon.constants;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import java.io.File;

/*
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Constant path for all files %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * @FilePath:dashboard.properties
 * @FilePath:homepage.properties
 * @FilePath:config.properties
 * @FilePath:log4j.properties
 * @FilePath:chromedriver.exe
 * @FilePath:geckodriver.exe
 * @FilePath:IEDriverServer.exe
 */
public class ConstantFilePath {

	public final static String USER_HOME = System.getProperty("user.dir") + File.separator;

	public final static String DASHBOARD_HOME = USER_HOME + "Resources" + File.separator + "locators" + File.separator;
	public final static String DASHBOARD_FILE = DASHBOARD_HOME + "dashboard.properties";

	public final static String USERS_HOME = System.getProperty("user.dir") + File.separator;
	public final static String HOMEPAGE_HOME = USERS_HOME + "Resources" + File.separator + "locators" + File.separator;
	public final static String HOMEPAGE_FILE = HOMEPAGE_HOME + "homepage.properties";

	public final static String CONFIG_HOME = USER_HOME + "Resources" + File.separator;
	public final static String CONFIG_FILE = CONFIG_HOME + "config.properties";

	public final static String LOG4J_HOME = USER_HOME + "Resources" + File.separator + "log4j" + File.separator;
	public final static String LOG4J_FILE = LOG4J_HOME + "log4j.properties";

	public final static String CHROME_HOME = USER_HOME + "lib" + File.separator;
	public final static String CHROME_FILE = CHROME_HOME + "chromedriver.exe";

	public final static String FIREFOX_HOME = USER_HOME + "lib" + File.separator;
	public final static String FIREFOX_FILE = FIREFOX_HOME + "geckodriver.exe";

	public final static String IE_HOME = USER_HOME + "lib" + File.separator;
	public final static String IE_FILE = IE_HOME + "IEDriverServer.exe";

}
