package com.atmecs.falcon.validatetest;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import org.testng.Assert;

import com.atmecs.falcon.logreports.LogReports;

public class ValidateTestResult {
	static LogReports report = new LogReports();

	public static boolean validateData(Object actual, Object expected, String message) {
		try {
			Assert.assertEquals(actual, expected);
			report.info("Passed : " + message + ": " + "Actual data : " + actual + "   " + "Expected :" + expected);
			return true;
		} catch (AssertionError assertionError) {
			return false;
		}
	}
}
