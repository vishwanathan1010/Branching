package com.atmecs.falcon.testbase;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.BasicConfigurator;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import com.atmecs.falcon.constants.ConstantFilePath;
import com.atmecs.falcon.logreports.LogReports;
import com.atmecs.falcon.utils.ReadLocatorsfile;

/*
 * @BaseClass of the project.
 * @Type of browser invoke.
 * @Valid URL of the application.
 */
public class TestBase {
	public WebDriver driver;
	LogReports log = new LogReports();
	Properties baseProperty;
	String url;
	String browser;
	String browserName;
	String browserVersion;
	String os;

	/*
	 * @Get OS name.
	 * 
	 * @Get browser name & version.
	 * 
	 * @Initialize the browser and valid URL.
	 */
	@BeforeClass
	public void initializeBrowser() throws IOException {
		baseProperty = ReadLocatorsfile.loadProperty(ConstantFilePath.CONFIG_FILE);

		url = baseProperty.getProperty("URL");
		browser = baseProperty.getProperty("Browser");

		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", ConstantFilePath.CHROME_FILE);
			driver = new ChromeDriver();
			log.info("Chrome browser is started...");
		} else if (browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", ConstantFilePath.FIREFOX_FILE);
			driver = new FirefoxDriver();
			log.info("Firefox browser is started...");
		} else if (browser.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.ie.driver", ConstantFilePath.IE_FILE);
			driver = new InternetExplorerDriver();
			log.info("IE browser is started...");
		}

		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
		browserName = caps.getBrowserName();
		browserVersion = caps.getVersion();

		os = System.getProperty("os.name").toLowerCase();
		log.info("OS: " + os + " and " + " Browser: " + browserName + " " + browserVersion);
		/*
		 * Get the valid URL and maximized the window.
		 */
		driver.get(url);
		log.info("Falcon application is open");
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		BasicConfigurator.configure();
	}

	/*
	 * Close the driver after finishing the automation test.
	 */
	@AfterClass
	public void endTest() {

		driver.quit();
	}

}
