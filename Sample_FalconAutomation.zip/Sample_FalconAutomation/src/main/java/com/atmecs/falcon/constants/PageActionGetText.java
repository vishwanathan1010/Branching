package com.atmecs.falcon.constants;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atmecs.falcon.logreports.LogReports;

/*
 * Content of methods for getText function
 */
public class PageActionGetText {
	public static String text;

	LogReports report = new LogReports();

	public String getText(WebDriver driver, LocatorType locator, String locatorValue, long timeOutInSeconds) {

		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);

		try {
			switch (locator) {
			case CLASSNAME:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.className(locatorValue)).getText();
				break;
			case CSSSELECTOR:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.cssSelector(locatorValue)).getText();
				break;
			case ID:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.id(locatorValue)).getText();
				break;
			case LINKTEXT:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.linkText(locatorValue)).getText();
				break;
			case NAME:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.name(locatorValue)).getText();
				break;
			case PARTIALLINKTEXT:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.partialLinkText(locatorValue)).getText();
				break;
			case TAGNAME:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.tagName(locatorValue)).getText();
				break;
			case XPATH:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				text = driver.findElement(By.xpath(locatorValue)).getText();
				break;
			default:
				break;
			}
		} catch (IllegalArgumentException illegalArgumentException) {
			report.info("Locator type doesn't exist" + illegalArgumentException.getCause());
		} catch (NullPointerException nullPointerException) {
			report.info("Locator type doesn't exist " + nullPointerException.getCause());
		} catch (Exception e) {

		}

		return text;

	}
}
