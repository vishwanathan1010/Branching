package com.atmecs.falcon.pages;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import org.openqa.selenium.WebDriver;

import com.atmecs.falcon.constants.LocatorType;
import com.atmecs.falcon.constants.PageActionClick;
import com.atmecs.falcon.constants.PageActionGetText;
import com.atmecs.falcon.utils.Utils;

/*
 * constant methods for HomePageNavigation testing scripts.
 */
public class HomePage {
	static PageActionClick clickPage;
	static PageActionGetText getText;

	/*
	 * FluentWait method way click for each module.
	 */
	public static void clickDashboard(WebDriver driver, final String xpath) {
		Utils.ignoreClickInterceptAndClickOnElement(driver, xpath);
	}

	public static void clickRecentRunsPage(WebDriver driver, final String xpath) {
		Utils.ignoreClickInterceptAndClickOnElement(driver, xpath);
	}

	public static void clickViewPage(WebDriver driver, final String xpath) {
		Utils.ignoreClickInterceptAndClickOnElement(driver, xpath);
	}

	public static void clickProductSnapshot(WebDriver driver, final String xpath) {
		Utils.ignoreClickInterceptAndClickOnElement(driver, xpath);
	}

	/*
	 * Switch case way click methods for each module.
	 */
	public static void clickDashboard(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		clickPage = new PageActionClick();
		clickPage.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	public static void clickRecentRunsPage(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		clickPage = new PageActionClick();
		clickPage.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	public static void clickViewPage(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		clickPage = new PageActionClick();
		clickPage.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	public static void clickProductSnapshot(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		clickPage = new PageActionClick();
		clickPage.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	/*
	 * switch case way methods for getText(Header title) from each module.
	 */
	public static String getDashboardText(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		getText = new PageActionGetText();
		getText.getText(driver, locator, locatorValue, timeOutInSeconds);
		return locatorValue;
	}

	public static String getRecentRunsText(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		getText = new PageActionGetText();
		getText.getText(driver, locator, locatorValue, timeOutInSeconds);
		return locatorValue;
	}

	public static String getProductSnapshotText(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		getText = new PageActionGetText();
		getText.getText(driver, locator, locatorValue, timeOutInSeconds);
		return locatorValue;
	}
}
