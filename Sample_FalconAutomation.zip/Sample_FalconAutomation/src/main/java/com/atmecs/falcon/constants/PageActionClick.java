package com.atmecs.falcon.constants;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.atmecs.falcon.constants.LocatorType;
import com.atmecs.falcon.logreports.LogReports;

/*
 * Content of methods for click function.
 */
public class PageActionClick {

	LogReports report = new LogReports();

	public boolean click(WebDriver driver, LocatorType locator, String locatorValue, long timeOutInSeconds) {

		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		boolean isClicked = true;

		try {
			switch (locator) {
			case CLASSNAME:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.className(locatorValue)).click();
				break;
			case CSSSELECTOR:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.cssSelector(locatorValue)).click();
				break;
			case ID:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.id(locatorValue)).click();
				break;
			case LINKTEXT:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.linkText(locatorValue)).click();
				break;
			case NAME:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.name(locatorValue)).click();
				break;
			case PARTIALLINKTEXT:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.partialLinkText(locatorValue)).click();
				break;
			case TAGNAME:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.tagName(locatorValue)).click();
				break;
			case XPATH:
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(locatorValue)));
				driver.findElement(By.xpath(locatorValue)).click();
				break;
			default:
				break;
			}
		} catch (IllegalArgumentException illegalArgumentException) {
			isClicked = false;
			report.info("Locator type doesn't exist" + illegalArgumentException.getCause());
		} catch (NullPointerException nullPointerException) {
			isClicked = false;
			report.info("Locator type doesn't exist " + nullPointerException.getCause());
		} catch (Exception e) {
			isClicked = false;
		}

		return isClicked;

	}

}
