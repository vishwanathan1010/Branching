package com.atmecs.falcon.utils;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadLocatorsfile {

	static Properties properties;
	static FileReader reader;
	static File file;

	/*
	 * get my data from constant property file.
	 */
	public static Properties loadProperty(String filePath) throws IOException {
		properties = new Properties();
		file = new File(filePath);
		reader = new FileReader(file);
		properties.load(reader);
		return properties;
	}

	public static String getData(String data) throws IOException {

		String filedata = properties.getProperty(data);
		return filedata;
	}
}
