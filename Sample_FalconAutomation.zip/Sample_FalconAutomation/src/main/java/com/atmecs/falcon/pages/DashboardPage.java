package com.atmecs.falcon.pages;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import org.openqa.selenium.WebDriver;

import com.atmecs.falcon.constants.DashUtils;
import com.atmecs.falcon.constants.LocatorType;
import com.atmecs.falcon.constants.PageActionClick;
import com.atmecs.falcon.constants.PageActionGetText;
import com.atmecs.falcon.utils.Utils;

public class DashboardPage {
	static PageActionGetText getText;
	static PageActionClick click;

	public static void clickDashboard(WebDriver driver, final String xpath) {
		Utils.ignoreClickInterceptAndClickOnElement(driver, xpath);
	}

	public static void getTrendText(WebDriver driver, final String xpath) {
		DashUtils.getDashboardData(driver, xpath);
	}

	public static String getLastRunValidation(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		getText = new PageActionGetText();
		getText.getText(driver, locator, locatorValue, timeOutInSeconds);
		return locatorValue;
	}

	public static void totalTestCasesValidation(WebDriver driver, final String xpath) {
		DashUtils.getDashboardData(driver, xpath);
	}

	public static void passDataValidation(WebDriver driver, final String xpath) {
		DashUtils.getDashboardData(driver, xpath);
	}

	public static void failDataValidation(WebDriver driver, final String xpath) {
		DashUtils.getDashboardData(driver, xpath);
	}

	public static void minimizeMenuBar(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		click = new PageActionClick();
		click.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	public static void maximizeMenuBar(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		click = new PageActionClick();
		click.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	public static void viewProductSnapshot(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		click = new PageActionClick();
		click.click(driver, locator, locatorValue, timeOutInSeconds);
	}

	public static void refreshDashboardPage(WebDriver driver, LocatorType locator, String locatorValue,
			long timeOutInSeconds) {
		click = new PageActionClick();
		click.click(driver, locator, locatorValue, timeOutInSeconds);
	}
}
