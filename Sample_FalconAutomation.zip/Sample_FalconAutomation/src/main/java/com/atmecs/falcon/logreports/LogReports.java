package com.atmecs.falcon.logreports;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 */
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.atmecs.falcon.constants.ConstantFilePath;

public class LogReports {

	Logger logger = null;

	public LogReports() {
		getlogger();
		logger = Logger.getLogger(LogReports.class.getName());
	}

	public void getlogger() {
		PropertyConfigurator.configure(ConstantFilePath.LOG4J_FILE);
	}

	public void info(String message) {
		logger.info(message);
	}

	public void debug(String message) {

	}
}
