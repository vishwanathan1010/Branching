package com.atmecs.falcon.testscripts;

/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 * @Test Scenario ID: TS_002
 * @TestCase ID: TC_005,TC_006,TC_007,TC_008,TC_009,TC_010,TC_011,TC_012,TC_013
 */
import java.io.IOException;
import java.util.Properties;
import org.testng.annotations.Test;
import com.atmecs.falcon.constants.ConstantFilePath;
import com.atmecs.falcon.constants.DashUtils;
import com.atmecs.falcon.constants.LocatorType;
import com.atmecs.falcon.constants.PageActionGetText;
import com.atmecs.falcon.logreports.LogReports;
import com.atmecs.falcon.pages.DashboardPage;
import com.atmecs.falcon.testbase.TestBase;
import com.atmecs.falcon.utils.ReadLocatorsfile;
import com.atmecs.falcon.validatetest.ValidateTestResult;

/*
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Scenario 2:Dashboard data validation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 */
public class DashboardData extends TestBase {

	LogReports log = new LogReports();
	Properties properties;

	@Test
	public void getPassTestResults() throws IOException, InterruptedException {
		/*
		 * get xpaths from property file.
		 */
		properties = ReadLocatorsfile.loadProperty(ConstantFilePath.DASHBOARD_FILE);

		String dashBoard = properties.getProperty("openDashboard");
		String trendDataPath = properties.getProperty("trendData");
		String lastRunData = properties.getProperty("lastRun");
		String totalTestCaseData = properties.getProperty("totalTestCase");
		String passData = properties.getProperty("passData");
		String failData = properties.getProperty("failData");
		String minimizeMenuBar = properties.getProperty("minimizeMenu");
		String maximizeManuBar = properties.getProperty("maximizeManu");
		String viewProductSnapShot = properties.getProperty("viewProductSnapShot");
		String refreshDashboard = properties.getProperty("refreshDashboard");
		/*
		 * Validation of data available in Dashboard module.
		 */
		log.info("Scenario:2 is started...");
		DashboardPage.clickDashboard(driver, dashBoard);
		log.info("DashBoard page is open");

		DashboardPage.getTrendText(driver, trendDataPath);
		ValidateTestResult.validateData(DashUtils.text, "Pass % Trend", "Trend data is Present");

		DashboardPage.getLastRunValidation(driver, LocatorType.XPATH, lastRunData, 15);
		ValidateTestResult.validateData(PageActionGetText.text, "Last Run", "LastRun data is Present");

		DashboardPage.totalTestCasesValidation(driver, totalTestCaseData);
		ValidateTestResult.validateData(DashUtils.text, "Total Test Cases", "Total test cases data is Present");

		DashboardPage.passDataValidation(driver, passData);
		ValidateTestResult.validateData(DashUtils.text, "Pass - 90%", "Pass data is Present.");

		DashboardPage.failDataValidation(driver, failData);
		ValidateTestResult.validateData(DashUtils.text, "Fail - 10%", "Fail data is Present.");

		DashboardPage.minimizeMenuBar(driver, LocatorType.XPATH, minimizeMenuBar, 15);
		log.info("Dashboard menu bar is minimized");

		DashboardPage.maximizeMenuBar(driver, LocatorType.XPATH, maximizeManuBar, 15);
		log.info("Dashboard menu bar is maximized");

		DashboardPage.viewProductSnapshot(driver, LocatorType.XPATH, viewProductSnapShot, 15);
		log.info("ViewProductSnapshot button from dashboard is present.");

		DashboardPage.refreshDashboardPage(driver, LocatorType.XPATH, refreshDashboard, 15);
		log.info("Dashboard page is refreshed");

		log.info("Scenario:2 is finished and All Test cases are passed...");
	}
}