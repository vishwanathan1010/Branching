package com.atmecs.falcon.testscripts;
/**
 * @Author name: Vishwanathan Mathesan
 * @Eclipse version: 2019-03(4.11.0)
 * @Selenium version: 3.141.59
 * @Created date: 07/31/2019
 * @Updated date: 08/01/2019
 * @Test Scenario ID: TS_001
 * @TestCase ID: TC_001,TC_002,TC_003,TC_004
 */

import java.io.IOException;
import java.util.Properties;
import org.testng.annotations.Test;
import com.atmecs.falcon.constants.ConstantFilePath;
import com.atmecs.falcon.constants.LocatorType;
import com.atmecs.falcon.constants.PageActionGetText;
import com.atmecs.falcon.logreports.LogReports;
import com.atmecs.falcon.pages.HomePage;
import com.atmecs.falcon.testbase.TestBase;
import com.atmecs.falcon.utils.ReadLocatorsfile;
import com.atmecs.falcon.validatetest.ValidateTestResult;

/*
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Scenario 1:Homepage validation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 */
public class HomePageNavigation extends TestBase {

	LogReports log = new LogReports();
	Properties properties;

	@Test
	public void getPassTestResults() throws IOException, InterruptedException {

		properties = ReadLocatorsfile.loadProperty(ConstantFilePath.HOMEPAGE_FILE);
		/*
		 * get xpaths from property file.
		 */

		String dashBoard = properties.getProperty("openDashboard");
		String recentRuns = properties.getProperty("openRecentRuns");
		String view = properties.getProperty("openView");
		// String productSnapshot = properties.getProperty("openProductSnapshot");

		String dashboardText = properties.getProperty("dashboardText");
		String recentRunsText = properties.getProperty("recentRunsText");
		/*
		 * Validation of each module is re-directed to appropriate page.
		 */
		log.info("Scenario:1 is started...");
		HomePage.clickDashboard(driver, dashBoard);
		log.info("DashBoard page is open");
		HomePage.getDashboardText(driver, LocatorType.XPATH, dashboardText, 10);
		ValidateTestResult.validateData(PageActionGetText.text, "Dashboard", "User re-directed to Dashboard page.");

		HomePage.clickRecentRunsPage(driver, recentRuns);
		log.info("Recent runs page is open");
		HomePage.getDashboardText(driver, LocatorType.XPATH, recentRunsText, 10);
		ValidateTestResult.validateData(PageActionGetText.text, "Recent Runs", "User re-directed to Recent runs page.");

		HomePage.clickViewPage(driver, view);
		log.info("View page is open");
		String viewPageURL = driver.getCurrentUrl();
		ValidateTestResult.validateData(viewPageURL, "http://falcon-dashboard.atmecs.corp:8082/#/reports/",
				"User re-directed to View page.");

		log.info("Scenario:1 is finished and All Test cases are passed...");

		/*
		 * HomePage.clickProductSnapshot(driver, productSnapshot);
		 * log.info("Product Snapshot page is open");
		 * //HomePage.getProductSnapshotText(driver, LocatorType.XPATH, locatorValue,
		 * timeOutInSeconds) ValidateTestResult.verifyBoolean(PageActionGetText.text,
		 * "Dashboard", "Dashboard is re-directed to appropriate page.");
		 */
	}
}
